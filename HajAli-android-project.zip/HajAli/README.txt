ساخت فایل نصبی (APK) حاج علی و دوستان

۱) Android Studio را نصب کن (رایگان، از developer.android.com/studio).
۲) File > Open و همین پوشه (HajAli) را انتخاب کن. صبر کن Gradle Sync تمام شود (اینترنت لازم است).
۳) Build > Build Bundle(s) / APK(s) > Build APK(s).
۴) فایل app-debug.apk در app/build/outputs/apk/debug ساخته می‌شود؛ آن را روی گوشی کپی و نصب کن
   (اجازه‌ی «نصب از منبع ناشناس» را بده).
محتوای برنامه در app/src/main/assets/index.html است.
